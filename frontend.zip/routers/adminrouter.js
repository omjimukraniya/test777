const router=require('express').Router()
const Reg=require('../models/reg')

router.get('/',(req,res)=>{
      res.render('admin/login.ejs')
})

router.post('/',async(req,res)=>{
      const {us,pass}=req.body
      const usercheck=await Reg.findOne({username:us})
      if(usercheck!==null){
            if(usercheck.password==pass){
                  res.redirect('/admin/dashboard')
            }else{
                  res.redirect('/admin/')
            }
      }else{
            res.redirect('/admin/')
      }


})




module.exports=router